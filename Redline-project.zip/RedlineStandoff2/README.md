# REDLINE Companion (Android)

This is a standalone Android Studio project for a red/black floating **visual demo overlay**. It draws synthetic demo shapes only; it does not read, modify, or interact with Standoff 2, and it does not implement cheats.

## Build an APK
1. Open this folder in Android Studio on a computer with Android SDK installed.
2. Allow Gradle sync and SDK downloads.
3. Select **Build → Build APK(s)**.
4. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

Requires JDK 17 for Android Gradle Plugin 8.3.0. On Android, granting "Display over other apps" permission is required for the floating demo.
