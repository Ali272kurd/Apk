package com.redline.standoff2.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.redline.standoff2.simulation.SimulationView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var sim: SimulationView
    private lateinit var bubble: TextView
    private lateinit var panel: LinearLayout
    private var panelShown = false
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sim = SimulationView(this)
        val sp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        wm.addView(sim, sp)
        bubble = TextView(this).apply { text = "R"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(190, 0, 20)); setOnClickListener { togglePanel() } }
        val bp = WindowManager.LayoutParams(dp(56), dp(56), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 180 }
        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=bp.x; oy=bp.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt(); if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) moved=true; bp.x=ox+dx; bp.y=oy+dy; wm.updateViewLayout(bubble,bp); return true }
                    MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); return true }
                }; return false
            }
        })
        wm.addView(bubble, bp)
        panel = buildPanel()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun buildPanel(): LinearLayout {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(16),dp(16),dp(16)); setBackgroundColor(Color.rgb(15,15,20)) }
        root.addView(TextView(this).apply { text="REDLINE  /  DEMO HUD"; textSize=20f; setTextColor(Color.rgb(229,9,20)) })
        root.addView(TextView(this).apply { text="Visual-only sandbox · not connected to Standoff 2"; textSize=12f; setTextColor(Color.LTGRAY) })
        fun check(label: String, initial: Boolean, action: (Boolean)->Unit) { root.addView(CheckBox(this).apply { text=label; setTextColor(Color.WHITE); isChecked=initial; setOnCheckedChangeListener { _, checked -> action(checked); sim.invalidate() } }) }
        check("Demo box",true){sim.showBox=it}; check("Demo name",true){sim.showName=it}; check("Demo health",true){sim.showHealth=it}; check("Demo tracer",true){sim.showTracer=it}; check("Show FOV circle",true){sim.showFov=it}
        root.addView(TextView(this).apply { text="Demo circle radius"; setTextColor(Color.WHITE) })
        root.addView(SeekBar(this).apply { max=300; progress=120; setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){sim.fovRadius=p.toFloat();sim.invalidate()}; override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){} }) })
        root.addView(Button(this).apply { text="CLOSE MENU"; setOnClickListener { togglePanel() } })
        return root
    }
    private fun togglePanel() {
        if (panelShown) { try { wm.removeView(panel) } catch (_: Exception) {}; panelShown=false }
        else { val p=WindowManager.LayoutParams(dp(320), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity=Gravity.CENTER }; wm.addView(panel,p); panelShown=true }
    }
    override fun onDestroy() { super.onDestroy(); try { wm.removeView(bubble) } catch (_: Exception) {}; try { wm.removeView(sim) } catch (_: Exception) {}; if(panelShown) try { wm.removeView(panel) } catch (_: Exception) {} }
}
