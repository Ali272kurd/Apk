package com.redline.standoff2.simulation

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class SimulationView(context: Context) : View(context) {
    private val boxPaint = Paint().apply { color = Color.parseColor("#E50914"); style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true }
    private val textPaint = Paint().apply { color = Color.WHITE; textSize = 26f; isAntiAlias = true }
    private val fovPaint = Paint().apply { color = Color.parseColor("#AAE50914"); style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
    var showBox = true; var showName = true; var showHealth = true; var showTracer = true; var showFov = true; var fovRadius = 120f
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas); val cx = width / 2f; val cy = height / 2f
        if (showFov) canvas.drawCircle(cx, cy, fovRadius * 2f, fovPaint)
        val left = width - 280f; val top = 160f; val right = width - 160f; val bottom = 360f
        if (showBox) canvas.drawRect(left, top, right, bottom, boxPaint)
        if (showName) canvas.drawText("Target [DEMO]", left, top - 10f, textPaint)
        if (showHealth) canvas.drawText("HP: 100", left, bottom + 25f, textPaint)
        if (showTracer) canvas.drawLine(cx, height.toFloat(), left + 60f, top, boxPaint)
    }
}
